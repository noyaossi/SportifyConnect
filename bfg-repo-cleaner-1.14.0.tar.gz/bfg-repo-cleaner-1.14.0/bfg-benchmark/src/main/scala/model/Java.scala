package model

case class Java(javaCmd: String, version: String)
